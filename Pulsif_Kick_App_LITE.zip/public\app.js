// Navigation
function showRegister() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
}

function showLogin() {
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
}

function login() {
    // Symulacja logowania
    const email = document.querySelector('#login-form input[type="email"]').value;
    if (email) {
        document.getElementById('auth-screen').style.display = 'none';
        document.getElementById('dashboard-screen').style.display = 'block';
        document.getElementById('username-display').innerText = email.split('@')[0];
    } else {
        alert("Wpisz email!");
    }
}

function logout() {
    document.getElementById('dashboard-screen').style.display = 'none';
    document.getElementById('auth-screen').style.display = 'flex';
}

function register() {
    alert("Konto założone! Możesz się zalogować.");
    showLogin();
}

// Bot Controls
async function startChatbot() {
    const channel = document.getElementById('streamer-name').value;
    if (!channel) return alert("Podaj nazwę kanału!");

    try {
        const response = await fetch('/api/start-bot', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ channel })
        });
        const data = await response.json();
        alert(data.message);
        document.getElementById('bot-count').innerText = "1";
    } catch (e) {
        console.error(e);
        alert("Błąd połączenia z serwerem. Upewnij się, że uruchomiłeś 'start_app.bat'");
    }
}

function stopChatbot() {
    fetch('/api/stop-bot').then(() => {
        alert("Bot zatrzymany.");
        document.getElementById('bot-count').innerText = "0";
    });
}

function openMonitor() {
    const channel = document.getElementById('streamer-name').value;
    if (!channel) return alert("Podaj nazwę kanału w sekcji obok!");

    fetch('/api/open-monitor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channel })
    });
}

function toggleClipper() {
    alert("Clipper aktywny! Bot nasłuchuje komendy !clip na czacie.");
}
